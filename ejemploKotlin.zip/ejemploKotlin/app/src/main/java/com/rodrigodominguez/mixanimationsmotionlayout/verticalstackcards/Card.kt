package com.rodrigodominguez.mixanimationsmotionlayout.verticalstackcards

import androidx.annotation.ColorInt

data class Card(
    @ColorInt val backgroundColor: Int
)