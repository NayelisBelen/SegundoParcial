package com.rodrigodominguez.mixanimationsmotionlayout.telegramheaderdemo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.rodrigodominguez.mixanimationsmotionlayout.R

class TelegramHeaderDemoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_telegram_header_demo)

    }

}