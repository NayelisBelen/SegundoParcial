package com.rodrigodominguez.mixanimationsmotionlayout.circularcards

import androidx.annotation.ColorInt

data class CreditCardModel(
    @ColorInt val backgroundColor: Int
)