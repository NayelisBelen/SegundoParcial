package com.rodrigodominguez.mixanimationsmotionlayout.verticalstackcards.scenes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.rodrigodominguez.mixanimationsmotionlayout.R

class VerticalStackCardsScene3Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vertical_stack_cards_scene3)
    }
}